<?php

return [
    //'hotel' => 'الفندق',
];
