<?php

return [
    //'hotel' => 'hotel',
];
