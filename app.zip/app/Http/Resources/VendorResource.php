<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class VendorResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $actionMethod = $request->route()->getActionMethod();
        return match ($actionMethod) {
            'getAll' => $this->getAllResource(),
             default => $this->defaultResource(),
        };
    }

    public function getAllResource()
    {
        return [
            'id'                   => $this->id,
            'name'                 => $this->name,
            'description'          => $this->description,
            'slug'                 => $this->slug,
            'latitude'             => $this->latitude,
            'longitude'            => $this->longitude,
            'address'              => $this->address,
            'phone'                => $this->phone,
            'email'                => $this->email,
            'is_active'            => $this->is_active,
            'vendor_category_id'   => $this->vendorCategory->id ?? null,
            'vendor_category_name' => $this->vendorCategory->name ?? null,
            'city_id'              => $this->city_id,
            'created_at'           => $this->created_at,
        ];

    }

    public function defaultResource()
    {
        return [
            'id'                   => $this->id,
            'name'                 => $this->name,
            'description'          => $this->description,
            'slug'                 => $this->slug,
            'latitude'             => $this->latitude,
            'longitude'            => $this->longitude,
            'address'              => $this->address,
            'phone'                => $this->phone,
            'email'                => $this->email,
            'is_active'            => $this->is_active,
            'vendor_category_id'   => $this->vendorCategory->id ?? null,
            'vendor_category_name' => $this->vendorCategory->name ?? null,
            'city_id'              => $this->city_id,
            'created_at'           => $this->created_at,
        ];


    }
}
