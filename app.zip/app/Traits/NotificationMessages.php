<?php

namespace App\Traits;

trait NotificationMessages
{

}
