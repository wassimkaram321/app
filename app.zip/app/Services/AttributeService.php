<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use App\Traits\ModelHelper;
use App\Models\Attribute;

class AttributeService
{
    use ModelHelper;

    public function getAll()
    {
        return Attribute::all();
    }

    public function find($attributeId)
    {
        return $this->findByIdOrFail(Attribute::class,'attribute', $attributeId);
    }

    public function create($validatedData)
    {
        DB::beginTransaction();

        $attribute = Attribute::create($validatedData);

        $attribute->values()->createMany(
            array_map(function ($value) {
                return ['value' => $value];
            }, $validatedData['values'])
        );

        DB::commit();

        return $attribute;
    }

    public function update($validatedData, $attributeId)
    {
        $attribute = $this->find($attributeId);

        DB::beginTransaction();

        $attribute->update($validatedData);
        $attribute->values()->delete();
        $attribute->values()->createMany(
            array_map(function ($value) {
                return ['value' => $value];
            }, $validatedData['values'])
        );

        DB::commit();

        return true;
    }

    public function delete($attributeId)
    {
        $attribute = $this->find($attributeId);

        DB::beginTransaction();

        $attribute->delete();

        DB::commit();

        return true;
    }
}
