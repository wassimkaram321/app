<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use App\Traits\ModelHelper;
use App\Models\Vendor;

class VendorService
{
    use ModelHelper;

    public function getAll()
    {
        return Vendor::all();
    }

    public function find($vendorId)
    {
        return $this->findByIdOrFail(Vendor::class,'vendor', $vendorId);
    }

    public function create($validatedData)
    {
        DB::beginTransaction();
        
        $validatedData['slug'] = \Str::slug($validatedData['name']);
        $vendor = Vendor::create($validatedData);

        DB::commit();

        return $vendor;
    }

    public function update($validatedData, $vendorId)
    {
        $vendor = $this->find($vendorId);

        DB::beginTransaction();

        $validatedData['slug'] = \Str::slug($validatedData['name']);
        $vendor->update($validatedData);

        DB::commit();

        return true;
    }
    public function updateStatus($validatedData, $vendorId)
    {
        $vendor = $this->find($vendorId);

        DB::beginTransaction();

        $vendor->update($validatedData);

        DB::commit();

        return true;
    }

    public function delete($vendorId)
    {
        $vendor = $this->find($vendorId);

        DB::beginTransaction();

        $vendor->delete();

        DB::commit();

        return true;
    }
}
