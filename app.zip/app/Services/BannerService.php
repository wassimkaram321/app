<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use App\Traits\ModelHelper;
use App\Models\Banner;

class BannerService
{
    use ModelHelper;

    public function getAll()
    {
        return Banner::all();
    }

    public function find($bannerId)
    {
        return $this->findByIdOrFail(Banner::class,'banner', $bannerId);
    }

    public function create($validatedData)
    {
        DB::beginTransaction();

        $banner = Banner::create($validatedData);

        DB::commit();

        return $banner;
    }

    public function update($validatedData, $bannerId)
    {
        $banner = $this->find($bannerId);

        DB::beginTransaction();

        $banner->update($validatedData);

        DB::commit();

        return true;
    }

    public function delete($bannerId)
    {
        $banner = $this->find($bannerId);

        DB::beginTransaction();

        $banner->delete();

        DB::commit();

        return true;
    }
    public function updateStatus($validatedData, $bannerId)
    {
        $banner = $this->find($bannerId);

        DB::beginTransaction();

        $banner->update($validatedData);

        DB::commit();

        return true;
    }
}
