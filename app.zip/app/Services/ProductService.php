<?php

namespace App\Services;

use App\Models\Attribute;
use Illuminate\Support\Facades\DB;
use App\Traits\ModelHelper;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Traits\CategorizableTrait;
use Ramsey\Uuid\Nonstandard\Uuid;

class ProductService
{
    use ModelHelper, CategorizableTrait;

    public function getAll()
    {
        return Product::all();
    }

    public function find($productId)
    {
        return $this->findByIdOrFail(Product::class, 'product', $productId);
    }

    public function create($validatedData)
    {
        DB::beginTransaction();

        $validatedData = $this->preperData($validatedData);

        $product = Product::create($validatedData);

        $this->addAttributesToProduct($product, $validatedData['attributes'] ?? []);

        $this->addFeaturesToProduct($product, $validatedData['features'] ?? []);


        DB::commit();

        return $product;
    }

    public function update($validatedData, $productId)
    {
        $product = $this->find($productId);

        DB::beginTransaction();

        $validatedData = $this->preperData($validatedData);

        $this->addAttributesToProduct($product, $validatedData['attributes'] ?? []);

        $this->addFeaturesToProduct($product, $validatedData['features'] ?? []);

        $product->update($validatedData);

        DB::commit();

        return true;
    }

    public function delete($productId)
    {
        $product = $this->find($productId);

        DB::beginTransaction();

        $product->delete();

        DB::commit();

        return true;
    }
    private function preperData($data)
    {

        $data['slug'] = \Str::slug($data['name']);
        $data['uuid'] = Uuid::uuid4()->toString();
        $data['categorizable_type'] = $this->getCategoryClass($data['categorizable_type']);

        return $data;
    }
    private function addAttributesToProduct($product,$attributesData)
    {


        $attributesToSync = collect($attributesData)->mapWithKeys(function ($attributeData) {
            $attribute = Attribute::find($attributeData['attribute_id']);

            if ($attribute) {
                return [
                    $attribute->id => [
                        'selected_value' => $attributeData['selected_value'],
                        'quantity' => $attributeData['quantity'],
                    ],
                ];
            }

            return [];
        })->toArray();

        $product->attributes()->sync($attributesToSync);
    }
    private function addFeaturesToProduct($product,$featuresData)
    {
        $product->features()->delete();
        $featuresToCreate = collect($featuresData)->map(function ($featureData) use ($product) {
            return [
                'title' => $featureData['title'],
                'content' => $featureData['content'],
                'product_id' => $product->id,
            ];
        });
        $product->features()->createMany($featuresToCreate->toArray());
    }
}
