<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BannerCategory extends Model
{
    use HasFactory;
    protected $fillable = [
        'type',
        'is_active'
    ];
    protected $casts = [
        'type'   => 'string',
        'is_active'   => 'boolean',
    ];
    public function banners()
    {
        return $this->hasMany(Banner::class);
    }
}
