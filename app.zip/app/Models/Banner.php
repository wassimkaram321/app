<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Banner extends Model implements HasMedia
{
    use HasFactory , InteractsWithMedia;
    protected $fillable = [
        'start_date',
        'end_date',
        'is_active',
        'banner_category_id',
        'vendor_id',
    ];
    protected $casts = [
        'start_date'           => 'date',
        'end_date'             => 'date',
        'is_active'            => 'boolean',
        'banner_category_id'   => 'integer',
        'vendor_id'            => 'integer',
    ];
    public function bannerCategory()
    {
        return $this->belongsTo(BannerCategory::class);
    }
}
