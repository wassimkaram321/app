<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Product extends Model implements HasMedia
{
    use HasFactory , InteractsWithMedia;
    protected $fillable = [
        'uuid',
        'name',
        'description',
        'price',
        'slug',
        'quantity',
        'vendor_id',
        'is_active',
        'is_returnable',
        'is_cancelable',
        'is_replaceable',
        'categorizable_id',
        'categorizable_type',
        'availability',
        'commission_id',
        'commission_value',
    ];
    protected $casts = [
        'name'                => 'string',
        'description'         => 'string',
        'price'               => 'double',
        'slug'                => 'string',
        'quantity'            => 'integer',
        'vendor_id'           => 'integer',
        'is_active'           => 'boolean',
        'is_returnable'       => 'boolean',
        'is_cancelable'       => 'boolean',
        'is_replaceable'      => 'boolean',
        'categorizable_id'    => 'integer',
        'categorizable_value' => 'string',
        'availability'        => 'string',
        'commission_id'       => 'integer',
        'commission_value'    => 'float',
    ];
    public function features()
    {
        return $this->morphMany(Feature::class, 'featureable');
    }
    public function categorizable()
    {
        return $this->morphTo();
    }
    public function commission()
    {
        return $this->belongsTo(Commission::class);
    }
    public function attributes()
{
    return $this->belongsToMany(Attribute::class,'product_attributes')->withPivot('selected_value', 'quantity');
}

}
