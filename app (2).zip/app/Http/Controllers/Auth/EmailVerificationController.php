<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\MedicalRepAuthRequest;

class EmailVerificationController extends Controller
{
    public function check_email(MedicalRepAuthRequest $request)
    {
    }

    public function verify_email(MedicalRepAuthRequest $request)
    {
    }
}
