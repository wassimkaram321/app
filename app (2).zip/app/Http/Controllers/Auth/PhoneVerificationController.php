<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\MedicalRepAuthRequest;
use Illuminate\Http\Request;

class PhoneVerificationController extends Controller
{

    public function check_phone(MedicalRepAuthRequest $request)
    {
        
    }

    public function verify_phone(MedicalRepAuthRequest $request)
    {

    }
}
