<?php
namespace App\Traits;
use Illuminate\Support\Str;

trait UploadImageTrait
{
    public function uploadImage($model, $file, $collectionName)
    {
        $model->clearMediaCollection($collectionName);
        $model->addMediaFromRequest($file)->toMediaCollection($collectionName);
    }
    public function uploadImages($model, $file, $collectionName)
    {
        foreach (request()->images as $image) {
            $model->addMedia($image)->toMediaCollection($collectionName);
        }
    }
}
